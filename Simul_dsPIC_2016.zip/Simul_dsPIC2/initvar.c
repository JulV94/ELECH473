#include <p33FJ256GP710.h>



int main (void)
{
char a = -76;
unsigned char b = 120;
int c = -27280;
unsigned int d = 55000;
long e = -2000000;
unsigned long f = 2000000;
long long g = 8000000000000001; 
unsigned long long h = 800000000000002;
}